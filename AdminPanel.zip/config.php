<?php
$db_host = 'localhost';
$db_username = 'root';
$db_database = 'db';
$db_password = 'root';

$panel_password = 'admin';
?>